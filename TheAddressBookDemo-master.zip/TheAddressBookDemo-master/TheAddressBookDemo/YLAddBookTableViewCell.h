//
//  YLAddBookTableViewCell.h
//  TheAddressBookDemo
//
//  Created by YangLei on 16/3/15.
//  Copyright © 2016年 YangLei. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "YLLabel.h"
@interface YLAddBookTableViewCell : UITableViewCell
@property (nonatomic,strong) UIImageView * imageviewright;
@property (nonatomic,strong) YLLabel * labelTou;
@property (nonatomic,strong) UILabel * labelmingzi;

@end
