//
//  YLPinYin.h
//  TheAddressBookDemo
//
//  Created by YangLei on 16/3/15.
//  Copyright © 2016年 YangLei. All rights reserved.
//

char pinyinFirstLetter(unsigned short hanzi);